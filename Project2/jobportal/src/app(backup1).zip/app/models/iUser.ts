export interface IUser {
    username: string;
    isAdminUser: boolean;
}
