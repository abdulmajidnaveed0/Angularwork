export interface IJob {
    jobid: number,
    category:string,
    jobtitle:string
}

