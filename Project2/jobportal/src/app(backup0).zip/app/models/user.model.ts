
//import {IUser} from './iUser';
export class User {
    username: string="";
    isAdminUser: boolean=false;
}
