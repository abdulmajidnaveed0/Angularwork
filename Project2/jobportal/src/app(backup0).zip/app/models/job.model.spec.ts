import { Job } from './job.model';

describe('Job', () => {
  it('should create an instance', () => {
    expect(new Job()).toBeTruthy();
  });
});
